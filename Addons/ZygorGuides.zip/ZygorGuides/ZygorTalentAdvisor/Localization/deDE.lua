if GetLocale()~="deDE" then return end

ZygorTalentAdvisor_L("Main", "deDE", function() return {
	-- ["English"] = "Localized",
} end)
